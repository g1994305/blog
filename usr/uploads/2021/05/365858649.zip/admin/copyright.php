<?php if(!defined('__TYPECHO_ADMIN__')) exit; ?>
<!-- 底部版权等信息 -->
</div>
<footer class="footer">
	<div class="d-sm-flex justify-content-center justify-content-sm-between">
		<span class="text-muted text-center text-sm-left d-block d-sm-inline-block">
			<a href="https://docs.mlwly.cn">帮助文档</a> &bull;
			<a href="https://forum.mlwly.cn">支持论坛</a> &bull;
			<a href="https://github.com/typecho/typecho/issues">报告错误</a> &bull;
			<a href="https://plugins.mlwly.cn">资源下载</a> &bull;
			<a href="https://github.com/BootstrapDash/PurpleAdmin-Free-Admin-Template">源项目</a>
			</span>
		<span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Fresh Thmem V3.0</span>
			
	</div>
</footer>
